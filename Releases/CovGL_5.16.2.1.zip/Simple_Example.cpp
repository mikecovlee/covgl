#include "CGL/CGL5.h"
int main(){return cgl::launch([&]{cgl::scr<<cov::handler<cgl::text>(new cgl::text("Happy Chinese New Year!")).modify();cgl::out<<cgl::scr;});}