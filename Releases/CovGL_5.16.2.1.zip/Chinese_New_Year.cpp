// Powered By Covariant GL
// This program need the Covariant GL version up to 5.16.1.1
#include "CGL/CGL5.h"
static const int pass_by_fps = 15;	// Move Speed
static cgl::text greeting("Happy Chinese New Year!");	// Greeting String
CreateThread(Main)				// Main Thread
{
	using namespace cgl;
	using namespace cov;
	int drawCount = 0;
	scr.back(color::red);		// Background Color
	greeting.text = color::yellow;	// Text Color
	greeting.back = scr.back();
	int pX(0), pY(0);
	bool iX(true), iY(true);
	SitLoop(Main)
	{
		OnRunningSit
		{
			if (drawCount >= pass_by_fps)
			{
				scr.reset();
				if (pX <= 0)
					iX = true;
				if (pY <= 0)
					iY = true;
				if (pX + greeting.size() > scr.width() - 1)
					iX = false;
				if (pY >= scr.height() - 1)
					iY = false;
				if (iX)
					++pX;
				else
					--pX;
				if (iY)
					++pY;
				else
					--pY;
				greeting.x = pX;
				greeting.y = pY;
				scr << greeting;
				out << scr;
				drawCount = 0;
			}
			else
			{
				out << scr;
				++drawCount;
			}
			EndSit;
		}
		EndSitLoop(Main);
	}
	EndThread(Main, ThreadSuccess);
}

int main()
{
	return cgl::launch([&]
					   {
					   Thread(Main).detach();
					   WaitForLeisure(Main); Thread(Main).resume(); WaitForExit(Main);}
	);
}