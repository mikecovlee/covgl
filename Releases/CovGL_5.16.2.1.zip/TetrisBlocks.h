namespace tetris
{
	static int BlockO[]
	{
	1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 2, 0, 2};
	static int BlockTr0[]
	{
	0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 2, 0, 3};
	static int BlockTr1[]
	{
	0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 3, 1, 2};
	static int BlockTr2[]
	{
	0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 2, 0, 3};
	static int BlockTr3[]
	{
	0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 3, 0, 2};
	static int BlockIr0[]
	{
	0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 3, 1, 1};
	static int BlockIr1[]
	{
	0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 3};
	static int BlockLr0[]
	{
	1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 3, 0, 2};
	static int BlockLr1[]
	{
	1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 2, 0, 3};
	static int BlockLr2[]
	{
	0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 3, 1, 2};
	static int BlockLr3[]
	{
	0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 0, 3};
	static int BlockJr0[]
	{
	0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 3, 1, 2};
	static int BlockJr1[]
	{
	0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 2, 0, 3};
	static int BlockJr2[]
	{
	1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 3, 0, 2};
	static int BlockJr3[]
	{
	1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 2, 0, 3};
	static int BlockZr0[]
	{
	0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 2, 0, 3};
	static int BlockZr1[]
	{
	0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 3, 0, 2};
	static int BlockZr2[]
	{
	1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 2, 0, 3};
	static int BlockZr3[]
	{
	0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 3, 1, 2};
	static int BlockSr0[]
	{
	0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 2, 0, 3};
	static int BlockSr1[]
	{
	1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 3, 0, 2};
	static int BlockSr2[]
	{
	0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 2, 0, 3};
	static int BlockSr3[]
	{
	0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 3, 1, 2};
	int *getblck(int blck, int angle)
	{
		switch (blck)
		{
		case 0:
			{
				return BlockO;
			}
			case 1:
			{
				switch (angle)
				{
				case 0:
					return BlockTr0;
				case 1:
					return BlockTr1;
				case 2:
					return BlockTr2;
				case 3:
					return BlockTr3;
				}
			}
		case 2:
			{
				switch (angle)
				{
				case 0:
					return BlockIr0;
				case 1:
					return BlockIr1;
				case 2:
					return BlockIr0;
				case 3:
					return BlockIr1;
				}
				break;
			}
		case 3:
			{
				switch (angle)
				{
				case 0:
					return BlockLr0;
				case 1:
					return BlockLr1;
				case 2:
					return BlockLr2;
				case 3:
					return BlockLr3;
				}
			}
		case 4:
			{
				switch (angle)
				{
				case 0:
					return BlockJr0;
				case 1:
					return BlockJr1;
				case 2:
					return BlockJr2;
				case 3:
					return BlockJr3;
				}
			}
		case 5:
			{
				switch (angle)
				{
				case 0:
					return BlockZr0;
				case 1:
					return BlockZr1;
				case 2:
					return BlockZr2;
				case 3:
					return BlockZr3;
				}
			}
		case 6:
			{
				switch (angle)
				{
				case 0:
					return BlockSr0;
				case 1:
					return BlockSr1;
				case 2:
					return BlockSr2;
				case 3:
					return BlockSr3;
				}
			}
		}
	}
}