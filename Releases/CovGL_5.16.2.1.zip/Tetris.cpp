#include "CGL/CGL5.h"
#include "TetrisBlocks.h"
namespace tetris
{
	class bit;					// 像素
	class block;				// 方块
	class tetris;				// 主程序类
}
class tetris::bit
{
  protected:
	cgl::surface mRender;		// 渲染器
  public:
	bit()
	{
		mRender.alpha(false);	// 关闭透明属性
		mRender.set(2, 1);		// 设置渲染器尺寸
	}
	cgl::surface & apply()
	{
		mRender.draw(0, 0, cgl::point('[', cgl::color::black, mRender.back()));
		mRender.draw(1, 0, cgl::point(']', cgl::color::black, mRender.back()));
		return mRender;
	}
	void color(char c)
	{
		mRender.back(c);
	}
	void color(cgl::c_color & c)
	{
		mRender.back(c);
	}
	cgl::c_color & color()
	{
		return mRender.back();
	}
};

class tetris::block
{
  protected:
	int mAngle;					// 旋转角度
	int mW, mH, mX, mY;
	cgl::c_color mColor;		// 背景色
	cgl::c_image < cov::handler < bit >> mMap;	// 图像
  public:
	block():mAngle(0), mW(0), mH(0), mX(0), mY(0)
	{
		mMap.set(3, 3);
		mColor.set_surface(cgl::color::ground::back);
	}
	virtual ~ block()
	{
	}
	cgl::c_image < cov::handler < bit >> &map()
	{
		return mMap;
	}
	void color(char c)
	{
		mColor = c;
	}
	void color(cgl::c_color & c)
	{
		mColor = c;
	}
	int angle() const
	{
		return mAngle;
	}
	int ix() const
	{
		return mX;
	}
	int iy() const
	{
		return mY;
	}
	int width() const
	{
		return mW;
	}
	int height() const
	{
		return mH;
	}
	cgl::c_color & color()
	{
		return mColor;
	}
	virtual void cast(int[13]);
	virtual void rotate(int angle)
	{
		// if (angle < 4)
		mAngle = angle;
	}
	virtual void apply(int x, int y, cgl::surface &);
};

class tetris::tetris
{
  public:
	int mScore;
	int mBlck;
	int mX, mY;
	cgl::window mWin;			// 程序窗体
	cgl::random mRand;			// 随机数生成器
	cgl::surface mSurf;			// 独立渲染器
	cgl::c_image < cov::handler < bit >> mMap;	// 地图
	cgl::c_image < cov::handler < bit >> mSwap;	// 地图缓存
	block mBlock;				// 方块实体
	void init();
	void fill(cgl::c_image < cov::handler < bit >> &);
	void clear(cgl::c_image < cov::handler < bit >> &);
	void generate();
	bool IsEmpty(std::vector < cov::handler < bit >> &);
	bool IsConnect(std::vector < cov::handler < bit >> &);
	bool checkConnect();
	void processConnect();
	void applyBlock(cgl::c_image < cov::handler < bit >> &);
	void applySurf(cgl::c_image < cov::handler < bit >> &);
	void applyWin();
  public:
	tetris():mWin(42, 24)
	{
		mSurf.alpha(false);
		mSurf.set(20, 20);
		mMap.set(10, 20);
		mSwap.set(10, 20);
	}
};
void tetris::block::cast(int img[9])
{
	for (int i = 0; i < 3; ++i)
	{
		for (int k = 0; k < 3; ++k)
		{
			mMap.read(k, i).free();
			if (img[i * 3 + k])
			{
				mMap.read(k, i).alloc();
				mMap.read(k, i).modify().color(mColor);
			}
		}
	}
	mY = img[9];
	mH = img[10];
	mX = img[11];
	mW = img[12];
}

void tetris::block::apply(int x, int y, cgl::surface & surf)
{
	int mX(x), mY(y);
	for (int row = 0; row < 3; ++row)
	{
		mX = x;
		for (int col = 0; col < 3; ++col)
		{
			auto ptr = mMap.read(col, row);
			if (ptr)
				surf.draw(mX, mY, ptr.modify().apply());
			mX += 2;
		}
		++mY;
	}
}

void tetris::tetris::init()
{
	mX = (10 - mBlock.width()) / 2 - mBlock.ix();
	mY = -mBlock.iy();
}

void tetris::tetris::fill(cgl::c_image < cov::handler < bit >> &img)
{
	std::vector < std::vector < cov::handler < bit >>> &array = img.array();
	for (int i = 0; i < img.height(); ++i)
	{
		for (int k = 0; k < img.width(); ++k)
		{
			array[k][i].free();
		}
	}
}

void tetris::tetris::clear(cgl::c_image < cov::handler < bit >> &img)
{
	std::vector < std::vector < cov::handler < bit >>> &array = img.array();
  for (auto & i:array)
	{
	  for (auto & k:i)
		{
			k.free();
		}
	}
}

void tetris::tetris::generate()
{
	mBlock.cast(getblck(mBlck, mBlock.angle()));
}

bool tetris::tetris::IsEmpty(std::vector < cov::handler < bit >> &line)
{
	int count = 0;
  for (auto & it:line)
	{
		if (!it)
			++count;
	}
	if (count == line.size())
		return true;
	else
		return false;
}

bool tetris::tetris::IsConnect(std::vector < cov::handler < bit >> &line)
{
	int count = 0;
  for (auto & it:line)
	{
		if (it)
			++count;
	}
	if (count == line.size())
		return true;
	else
		return false;
}

bool tetris::tetris::checkConnect()
{
	mSwap = mMap;
	applyBlock(mSwap);
	std::vector < std::vector < cov::handler < bit >>> &array = mSwap.array();
  for (auto & it:array)
	{
		if (IsConnect(it))
			return true;
	}
	return false;
}

void tetris::tetris::processConnect()
{
	std::vector < std::vector < cov::handler < bit >>> &array = mMap.array();
	std::vector < std::vector < cov::handler < bit >>> &swap = mSwap.array();
  for (auto & it:array)
	{
		if (IsConnect(it))
		{
		  for (auto & obj:it)
			{
				obj.free();
			}
		}
	}
	int sPosit = swap.size() - 1;
	for (int line = array.size() - 1; line >= 0; --line)
	{
		if (!IsEmpty(array[line]))
		{
			swap[sPosit] = array[line];
			--sPosit;
		}
	}
	clear(mMap);
	mMap = mSwap;
}

void tetris::tetris::applyBlock(cgl::c_image < cov::handler < bit >> &image)
{
	cgl::c_image < cov::handler < bit >> *objImg = &mBlock.map();
	for (int i = 0; i < 3; ++i)
	{
		for (int k = 0; k < 3; ++k)
		{
			if (objImg->read(k, i))
			{
				image.read(mX + k, mY + i).assign(objImg->read(k, i).data());
			}
		}
	}
}

void tetris::tetris::applySurf(cgl::c_image < cov::handler < bit >> &img)
{
	int X(0), Y(0);
	for (int row = 0; row < img.height(); ++row)
	{
		X = 0;
		for (int col = 0; col < img.width(); ++col)
		{
			auto ptr = img.read(col, row);
			if (ptr)
				mSurf.draw(X, Y, ptr.modify().apply());
			X += 2;
		}
		++Y;
	}
}

int start()
{
	cgl::scr.back(cgl::color::white);
	tetris::tetris mainProg;
	mainProg.mBlock.color(mainProg.mRand.get('0', '6'));
	mainProg.mBlck = mainProg.mRand.get(0, 6);
	mainProg.generate();
	mainProg.init();
	mainProg.fill(mainProg.mSwap);
	mainProg.applyBlock(mainProg.mSwap);
	while (true)
	{
		int input = cgl::out.GetKbHitPer(1000000);
		if (input != -1)
		{
			switch (input)
			{
			case cgl::keyboard::enter:
				{
					mainProg.mBlock.color(mainProg.mRand.get('0', '6'));
					mainProg.mBlck = mainProg.mRand.get(0, 6);
					mainProg.generate();
					mainProg.init();
					break;
				}
			case cgl::keyboard::num_select:
				{
					mainProg.init();
					break;
				}
			case cgl::keyboard::num_left:
				{
					--mainProg.mX;
					break;
				}
			case cgl::keyboard::num_right:
				{
					++mainProg.mX;
					break;
				}
			default:
				{
					mainProg.mBlock.rotate(mainProg.mBlock.angle() + 1);
					if (mainProg.mBlock.angle() == 4)
						mainProg.mBlock.rotate(0);
					mainProg.generate();
					break;
				}
			}
		}
		else
			++mainProg.mY;
		cgl::scr.reset();
		mainProg.mSurf.reset();
		mainProg.clear(mainProg.mSwap);
		mainProg.applyBlock(mainProg.mSwap);
		mainProg.applySurf(mainProg.mSwap);
		cgl::scr.draw(2, 1, mainProg.mSurf);
		cgl::out << cgl::scr;
	}
}

int main()
{
	cgl::launch(start);
}