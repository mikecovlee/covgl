#include "CGL/CGL5.h"
#include <cmath>
#include <list>
class posit
{
	double mX, mY;
  public:
	  posit():mX(0), mY(0)
	{
	}
	posit(double x, double y):mX(x), mY(y)
	{
	}
	~posit() = default;
	double x() const
	{
		return mX;
	}
	double y() const
	{
		return mY;
	}
	void x(double ix)
	{
		mX = ix;
	}
	void y(double iy)
	{
		mY = iy;
	}
};

class line
{
	posit mBegin, mEnd;
  public:
	  line() = delete;
	  line(posit b, posit e):mBegin(b), mEnd(e)
	{
	}
	 ~line() = default;
	const posit & begin() const
	{
		return mBegin;
	}
	const posit & end() const
	{
		return mEnd;
	}
	void begin(const posit & b)
	{
		mBegin = b;
	}
	void end(const posit & e)
	{
		mEnd = e;
	}
	double distance() const
	{
		return sqrt(pow(mBegin.x() - mEnd.x(), 2) + pow(mBegin.y() - mEnd.y(), 2));
	}
	posit middle() const
	{
		return posit((mBegin.x() + mEnd.x()) / 2, (mBegin.y() + mEnd.y()) / 2);
	}
};
void getLine(line nl, std::list < posit >& posits)
{
	line ll(nl.begin(), nl.middle()), rl(nl.middle(), nl.end());
	while (rl.distance() >= 1)
	{
		if (ll.distance() <= 1)
		{
			posits.push_back(ll.middle());
			ll.begin(rl.begin());
			ll.end(rl.middle());
			rl.begin(rl.middle());
			continue;
		}
		rl.begin(ll.middle());
		ll.end(ll.middle());
	}
}

using namespace cgl;
double f0(int x)
{
	return x * 8;
}

double f1(int x)
{
	return pow(2, x - 2);
}

int start()
{
	surface surf;
	surf.set(40, 20);
	std::list < posit > line0;
	std::list < posit > line1;
	for (int x = 1; x * 2 < surf.width(); ++x)
	{
		getLine(line(posit(x, f0(x)), posit(x + 1, f0(x + 1))), line0);
		getLine(line(posit(x, f1(x)), posit(x + 1, f1(x + 1))), line1);
	}
  for (auto & it:line0)
	{
		surf.draw(it.x() * 2, surf.high() - 1 - it.y(), '#');
	}
  for (auto & it:line1)
	{
		surf.draw(it.x() * 2, surf.high() - 1 - it.y(), '@');
	}
	out.limit_fps = 2;
	while (true)
	{
		scr.reset();
		scr.draw(0, scr.high() - surf.high(), surf);
		out << scr;
	}
}

int main()
{
	return launch(start);
}