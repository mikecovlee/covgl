#ifndef GUARD_CGL5_CE_H


#define GUARD_CGL5_CE_H


namespace cgl
{
	typedef baseImage surface;
	typedef baseView screen;
	class baseConsole;
}


class cgl::baseConsole
{
  protected:
	baseView * __scr;
	std::list < cov::handle < point > >__buff;
	std::list < std::list < cov::handle < point > >>__sbuf;
	char str_buff[16];
	point __cursor;
	void recover()
	{
		while (__buff.size() > __scr->high() * __scr->width())
			__buff.pop_front();
	}
	void print_to_scr()
	{
		__scr->reset();
		__sbuf.clear();
		std::list < cov::handle < point > >swap;
		for (auto it = __buff.begin(); it != __buff.end(); ++it)
		{
			if (swap.size() == __scr->width())
			{
				__sbuf.push_back(swap);
				swap.clear();
			}
			if (it->data() == '\n')
			{
				__sbuf.push_back(swap);
				swap.clear();
				auto tmp = it;
				if (++tmp == __buff.end())
				{
					__sbuf.push_back(swap);
					break;
				}
			}
			else
				swap.push_back(*it);
		}
		if (!swap.empty())
			__sbuf.push_back(swap);
		while (__sbuf.size() > __scr->high())
			__sbuf.pop_front();
		int px, py;
		py = __sbuf.size() - 1;
		for (auto it = __sbuf.rbegin(); it != __sbuf.rend() && py >= 0; ++it)
		{
			px = it->size() - 1;
			for (auto tp = it->rbegin(); tp != it->rend(); ++tp)
			{
				__scr->draw(px, py, tp->data());
				--px;
			}
			--py;
		}
		if (!__buff.empty())
		{
			if (__sbuf.back().size() == __scr->width() && __sbuf.size() < __scr->high() - 1)
				__scr->draw(0, __sbuf.size(), '_');
			else
				__scr->draw(__sbuf.back().size(), __sbuf.size() - 1, '_');
		}
		else
			__scr->draw(0, 0, '_');
		out << *__scr;
	}
  public:
  baseConsole():__scr(&scr)
	{
	}
  baseConsole(baseView & s):__scr(&s)
	{
	}
	virtual ~ baseConsole()
	{
	}
	void SetColor(char color, char ground = color::ground::fore)
	{
		switch (ground)
		{
		case color::ground::fore:
			__cursor.text = color;
			break;
		case color::ground::back:
			__cursor.back = color;
			break;
		}
	}
	void SetAttri(char attri)
	{
		__cursor.attri = attri;
	}
	template < typename T > void print(const T);
	void output()
	{
		print_to_scr();
	}
	template < typename T, typename...Argt > void output(const T & obj, const Argt & ... args)
	{
		recover();
		print(obj);
		output(args...);
	}
	template < typename T > baseConsole & operator<<(const T & obj)
	{
		recover();
		print(obj);
		return *this;
	}
};


namespace cgl
{
	template <> void baseConsole::print < point > (const point p)
	{
		__buff.push_back(p);
	}
	template <> void baseConsole::print < char >(const char c)
	{
		__cursor = c;
		if (__cursor.data() == keyboard::back_space)
		{
			if (!__buff.empty())
				__buff.pop_back();
		}
		else
		{
			__buff.push_back(__cursor);
		}
	}
	template <> void baseConsole::print < int >(int i)
	{
		sprintf(str_buff, "%d", i);
		for (int i = 0; i < cov::strlen(str_buff); ++i)
		{
			__cursor = str_buff[i];
			__buff.push_back(__cursor);
		}
	}
	template <> void baseConsole::print < double >(const double d)
	{
		sprintf(str_buff, "%f", d);
		for (int i = 0; i < cov::strlen(str_buff); ++i)
		{
			__cursor = str_buff[i];
			__buff.push_back(__cursor);
		}
	}
	template <> void baseConsole::print < char *>(char *str)
	{
		for (int i = 0; i < cov::strlen(str); ++i)
		{
			__cursor = str[i];
			__buff.push_back(__cursor);
		}
	}
	template <> void baseConsole::print < const char *>(const char *str)
	{
		for (int i = 0; i < cov::strlen(str); ++i)
		{
			__cursor = str[i];
			__buff.push_back(__cursor);
		}
	}
	template <> void baseConsole::print < void (*) () > (void (*func) ())
	{
		if (func == ioctrl::endl)
			print('\n');
		if (func == ioctrl::flush)
			print_to_scr();
	}
}


namespace cgl
{
	typedef baseConsole console;
}


#endif