#ifndef COV_GENERICTYPE_H


#define COV__GENERICTYPE_H


#include <cstdio>


namespace cov
{
	template < typename T > class handle
	{
	  protected:
		T * m_ptr;
		long *ref;
	  public:
		  handle():m_ptr(new T), ref(new long (1))
		{
		}
		handle(const T & obj):m_ptr(new T(obj)), ref(new long (1))
		{
		}
		handle(const handle & obj):m_ptr(obj.m_ptr), ref(obj.ref)
		{
			++*ref;
		}
		~handle()
		{
			if (--*ref == 0)
			{
				delete m_ptr;
				delete ref;
			}
		}
		const T & data()
		{
			return *m_ptr;
		}
		T & reality()
		{
			if (*ref > 1)
			{
				--*ref;
				ref = new long (1);
				m_ptr = new T(*m_ptr);
			}
			return *m_ptr;
		}
		operator     const T & ()
		{
			return *m_ptr;
		}
		const T *operator->()
		{
			return m_ptr;
		}
		const T & operator=(const T & obj)
		{
			if (*ref > 1)
			{
				--*ref;
				ref = new long (1);
				m_ptr = new T(*m_ptr);
			}
			*m_ptr = obj;
			return obj;
		}
		const handle & operator=(const handle & obj)
		{
			if (&obj != this)
			{
				if (--*ref == 0)
				{
					delete m_ptr;
					delete ref;
				}
				ref = obj.ref;
				m_ptr = obj.m_ptr;
				++*ref;
			}
			return *this;
		}
	};
	int strlen(const char *str)
	{
		if (*str == '\0')
			return 0;
		int siz = 0;
		while (*(str + (++siz)));
		return siz;
	}
	enum types
	{
		integer = 0xEA,
		floating = 0xEB,
		boolean = 0xEC,
		string = 0xED
	};
	class generic
	{
	  protected:
		char tmp[16];
		union
		{
			int integer;
			double floating;
			bool boolean;
			char *string;
		} m_value;
		int m_type;
	  public:
		  generic():m_type(types::integer)
		{
		}
		generic(int typ):m_type(typ)
		{
		}
		template < typename T > generic(int typ, const T & v):m_type(typ)
		{
			assign(m_type, v);
		}
		int type()
		{
			return m_type;
		}
		template < typename T > bool assign(T v)
		{
			return false;
		}
		template < typename T > generic & operator=(T v)
		{
			assign(v);
			return *this;
		}
		const char *val()
		{
			switch (m_type)
			{
			case types::integer:
				sprintf(tmp, "%d", m_value.integer);
				return tmp;
			case types::floating:
				sprintf(tmp, "%f", m_value.floating);
				return tmp;
			case types::boolean:
				if (m_value.boolean)
					return "true";
				else
					return "false";
			case types::string:
				return m_value.string;
			}
			throw;
		}
		operator     const char *()
		{
			return val();
		}
		template < typename T > T eval()
		{
			throw;
		}
	};
	template <> bool generic::assign < int >(int v)
	{
		m_value.integer = v;
		m_type = types::integer;
		return true;
	}
	template <> bool generic::assign < double >(double v)
	{
		m_value.floating = v;
		m_type = types::floating;
		return true;
	}
	template <> bool generic::assign < bool > (bool v)
	{
		m_value.boolean = v;
		m_type = types::boolean;
		return true;
	}
	template <> bool generic::assign < char *>(char *v)
	{
		m_value.string = v;
		m_type = types::string;
		return true;
	}
	template <> int generic::eval < int >()
	{
		switch (m_type)
		{
		case types::integer:
			return m_value.integer;
		case types::floating:
			return m_value.floating;
		case types::boolean:
			return m_value.boolean;
		}
		throw;
	}
	template <> double generic::eval < double >()
	{
		switch (m_type)
		{
		case types::integer:
			return m_value.integer;
		case types::floating:
			return m_value.floating;
		case types::boolean:
			return m_value.boolean;
		}
		throw;
	}
	template <> bool generic::eval < bool > ()
	{
		if (m_type == types::boolean)
			return m_value.boolean;
		throw;
	}
	template <> char *generic::eval < char *>()
	{
		if (m_type == types::string)
			return m_value.string;
		throw;
	}
}


#endif