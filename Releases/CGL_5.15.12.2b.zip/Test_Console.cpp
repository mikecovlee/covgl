#include "CGL/CGL5.h"
#include <thread>


static bool hang_up = true;
static bool running = true;
static char input;


void main_func()
{
	while (running)
	{
		if (!hang_up)
		{
			input = out.GetKbHit();
			hang_up = true;
		}
	}
}


int start()
{
	std::thread ign(main_func);
	ign.detach();
	hang_up = false;
	while (true)
	{
		if (hang_up)
		{
			cgl::cons << (char)input;
			hang_up = false;
		}
		else
			cgl::cons << cgl::ioctrl::flush;
	}
}


int main()
{
	cgl::launch(start);
}