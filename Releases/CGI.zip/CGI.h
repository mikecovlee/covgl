#ifndef GUARD_CGI_H
#define GUARD_CGI_H
//Console Graphics Interface
//T&C Studio Present
//Compile By Mike Lee
//Copyright 2015 (C) T&C Studio
//Version 1.0.0 Formal
//Notice:Don't use UTF Chars!Only support English.
#include<iostream>
#include<string>
#include<vector>
#include<termios.h>
#include<sys/types.h>
#include<sys/ioctl.h>
#include<unistd.h>
//Please use namespace cgi.
namespace cgi {
	//Special char class
  class point {
  public:
    char img;
      std::string t_color;
      std::string b_color;
      point() {
      img = '@';
      t_color = "37";
      b_color = "40";
  }};
  //Of the screen pencil class
  class pencil {
  public:
    int x, y;
    point nib;
      pencil() {
      x = y = 0;
      nib.img = '@';
      nib.t_color = "37";
      nib.b_color = "40";
  }};
  //Buffer class
  class buffer {
  	//friend declaration
    friend class screen;
    friend bool operator<<(pencil,pencil);
  private:
      bool use;
    point init_p;
    int width, high;
    //Basic implementation
      std::vector < std::vector < point >> i_buffer;
  public:
      buffer() {
      use = false;
    }
    //Initialization function
    void init(int w, int h) {
      use = true;
      init_p.img = ' ';
      width = w;
      high = h;
      i_buffer.resize(high);
      for (int i = 0; i != high; ++i)
        i_buffer[i].resize(width);
      for (int i = 0; i != high; ++i)
        for (int k = 0; k != width; ++k)
          i_buffer[i][k] = init_p;
    }
    //Realize the draw
    bool operator<<(pencil tmp) {
      if (!use || tmp.x < 0 || tmp.y < 0 || tmp.x >= width || tmp.y >= high)
        return false;
      i_buffer[tmp.y][tmp.x] = tmp.nib;
      return true;
    }
    //Reset the buffer
    void clean() {
      if (!use)
        return;
      for (int i = 0; i != high; ++i)
        for (int k = 0; k != width; ++k)
          i_buffer[i][k] = init_p;
    }
  };
  //Main implementation modules
  class screen {
  private:
    int wid, hig;
    void clear() {
      std::cout << "\x1B[2J\x1B[0;0f";
  } public:
      buffer renderer;
    screen() {
    	//Access to the screen size and initialize the elements
      struct winsize size;
      ioctl(STDIN_FILENO, TIOCGWINSZ, &size);
      wid = size.ws_col;
      hig = size.ws_row - 6;
      renderer.init(wid, hig);
    }
    //To draw on the screen
    void update_scr() {
      std::cout << "\33[?25l";
      clear();
      for (int i = 0; i != renderer.i_buffer.size(); ++i) {
        for (int k = 0; k != renderer.i_buffer[i].size(); ++k)
          std::cout << "\e[" + renderer.i_buffer[i][k].t_color + ";1m\e[" +
            renderer.i_buffer[i][k].b_color + ";1m" +
            renderer.i_buffer[i][k].img;
        std::cout << std::endl;
      }
      usleep(12000);
    }
    int width() {
      return wid;
    }
    int high() {
      return hig;
    }
    void clean() {
      renderer.clean();
      clear();
    }
  };
}
int cgi_main(int,char**);
int main(int argc,char** argv) {
  return cgi_main(argc ,argv );
}
#define main cgi_main
#endif