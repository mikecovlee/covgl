#include"CGI.cpp"
#include"CGI_Views.cpp"
int cgi_main() {
  cgi::screen scr;
  pencil pen;
  pen.nib.img = ' ';
  pen.nib.b_color = "47";
  pen.x = scr.high() - 1;
  bool tst = false;
  double a=0.05;
  double b=(scr.width()-1)*a;
  int c=2+(b*b)/(4*a);
  while (true) {
    if (tst) {
      pen.nib.b_color = "42";
      tst = false;
    } else {
      pen.nib.b_color = "47";
      tst = true;
    }
    pen.x = pen.y = 0;
    int mx = 0;
    while (pen.y < scr.high() && pen.x < scr.width()) {
      int my = a * mx * mx - b * mx + c;
      pen.x = mx;
      pen.y = my;
      ++mx;
      scr << pen;
      scr.updscr();
    }
  }
}