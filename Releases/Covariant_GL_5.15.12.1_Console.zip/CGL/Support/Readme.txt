﻿当使用Linux(G++ With Glibc)环境进行编译时务必加入以下参数:
When using ﻿ Linux(G++ With Glibc)environment to compile time it is important to join the following parameters:
-Wl,--no-as-needed -std=c++11 -lpthread
