#ifndef GUARD_CGL5_CE_H


#define GUARD_CGL5_CE_H


namespace cgl
{
	typedef baseImage surface;
	typedef baseView screen;
}


#endif