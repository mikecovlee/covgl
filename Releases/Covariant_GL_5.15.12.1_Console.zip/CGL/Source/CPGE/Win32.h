#ifndef CGL_CPGE_WIN32_H


#define CGL_CPGE_WIN32_H


#include <windows.h>


namespace cgl
{
	namespace priv_realize		// 具体功能实现
	{
		inline void set_cursor_visible(bool);
	}
	// 重载cgl::print实现扩展
	inline void print(const int &);
	inline void print(const char &);
	inline void print(const char *);
	inline void print(void (*)());
}


inline void cgl::priv_realize::set_cursor_visible(bool visible)
{
	// 设置光标可见状态
	HANDLE hout;
	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cci = { 1, visible };
	SetConsoleCursorInfo(hout, &cci);
}


inline void cgl::print(const int &i)
{
	// int类型输出
	printf("%d", i);
}


inline void cgl::print(const char &c)
{
	// char类型输出
	printf("%c", c);
}


inline void cgl::print(const char *s)
{
	// 字符串输出
	printf("%s", s);
}


inline void cgl::print(void (*func) ())
{
	// cgl::ioctrl实现，调用具体函数
	func();
}


inline void cgl::ioctrl::flush()
{
	// 刷新缓冲区
	fflush(stdout);
}


inline void cgl::ioctrl::endl()
{
	// 结束当前行并刷新缓冲区
	printf("\n");
	fflush(stdout);
}


template < typename Type > inline void cgl::print(const Type & obj)
{
	// 泛型调用算法
	print(obj);
}


template < typename Type, typename...Argt >
	inline void cgl::print(const Type & obj, const Argt & ... argv)
{
	// 使用C++11的模板参数包实现，使用重载和递归解包
	print(obj);
	print(argv...);
}


inline int cgl::get_terminal_width()
{
	// 获取终端宽度
	HANDLE hout;
	CONSOLE_SCREEN_BUFFER_INFO bInfo;
	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hout, &bInfo);
	return bInfo.dwSize.X;
}


inline int cgl::get_terminal_high()
{
	// 获取终端高度
	HANDLE hout;
	CONSOLE_SCREEN_BUFFER_INFO bInfo;
	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hout, &bInfo);
	return bInfo.dwSize.Y;

}


inline void cgl::reset_character_attri()
{
	// 恢复默认字符属性
}


inline void cgl::set_character_attri(char *attri)
{
	// 设置字符属性
	// 关于字符属性代码详见cpge.h
	// [0]为字符属性
	// [1],[2]为字符前景色
	// [3],[4]为字符背景色
	// [5]为填充的\0
}


bool cgl::basic::KbHit()
{
	// 判断键盘是否有输入，原型是TCC中conio.h里的kbhit()
}


int cgl::basic::GetKbHit()
{
	// 获取键盘输入，原型是TCC中conio.h里的getch()
}


int cgl::basic::GetKbHitPer(unsigned long wait = 0)
{
	// 在指定时间内获取键盘输入，如超时无键入则返回-1，时间单位为微秒
}


void cgl::basic::Echo(bool in)
{
	// 控制输入回显和光标的开和关
}


void cgl::basic::rst_cursor()
{
	// 重置光标到(0,0)
	HANDLE hout;
	COORD coord = { 0, 0 };
	hout = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hout, coord);
}


void cgl::basic::ClrScr()
{
	// 清屏
}


#endif