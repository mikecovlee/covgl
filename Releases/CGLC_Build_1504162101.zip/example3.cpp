#include"CGLC_Views"
int cglc_main() {
  cglc::screen scr;
  cglc::window win(scr);
  pencil pen;
  pen.nib = ' ';
  pen.nib.back = "47";
  win.renderer.back = "46";
  win.clean();
  bool tst = false;
  while (true) {
    if (tst) {
      pen.nib.back = "46";
      tst = false;
    } else {
      pen.nib.back = "47";
      tst = true;
    }
    for (pen.y = 0; pen.y < win.high(); ++pen.y)
      for (pen.x = 0; pen.x < win.width(); ++pen.x) {
        win << pen;
        win.updscr();
      }
  }
}