#include "CGL/CGL5.h"
#include <thread>


static bool hang_up = true;
static bool running = true;
static char input;


void main_func()
{
	while (running)
	{
		if (!hang_up)
		{
			input = cgl::out.GetKbHit();
			hang_up = true;
		}
	}
}


int start()
{
	std::thread ign(main_func);
	ign.detach();
	hang_up = false;
	cgl::window win(cgl::scr);
	win.title("CGL Terminal");
	win.back(cgl::color::white);
	win.render_back(cgl::color::black);
	win.border_color(cgl::color::black);
	win.border(' ');
	cgl::console < cgl::window > con(win);
	win.show();
	win.focus();
	con << "Covariant GL 5 Terminal Emulator" << cgl::ioctrl::endl << "$:/>";
	while (true)
	{
		if (hang_up)
		{
			con.input_mod(true);
			con << (char)input;
			if (!con.input_mod())
			{
				std::string input = con.input();
				if (input == "clear")
					con.ClrScr();
				if (input == "exit")
					break;
				con << "$:/>";
			}
			hang_up = false;
		}
		else
			con << cgl::ioctrl::flush;
	}
	return 0;
}



int main()
{
	cgl::launch(start);
}