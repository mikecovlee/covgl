#include"CGLC.cpp"
#include"CGLC_Views.cpp"
int cglc_main() {
  cglc::screen scr;
  pencil pen;
  pen.nib.img = ' ';
  pen.nib.back = "47";
  scr.renderer.back = "46";
  scr.clean();
  bool tst = false;
  while (true) {
    if (tst) {
      pen.nib.back = "46";
      tst = false;
    } else {
      pen.nib.back = "47";
      tst = true;
    }
    for (pen.y = 0; pen.y < scr.high(); ++pen.y)
      for (pen.x = 0; pen.x < scr.width(); ++pen.x) {
        scr << pen;
        scr.updscr();
      }
  }
}