// CGLC函数外部定义文件
// Build 15-04-15-200-10
#include"CGLC.h"
static int irefresh;
void cglc::buffer::init(int w, int h) {
  use = true;
  init_p.img = ' ';
  width = w;
  high = h;
  i_buffer.resize(high);
  for (int i = 0; i != high; ++i)
    i_buffer[i].resize(width);
  for (int i = 0; i != high; ++i)
    for (int k = 0; k != width; ++k)
      i_buffer[i][k] = init_p;
}
void cglc::buffer::clean() {
  if (!use)
    return;
  init_p.back = back.color();
  for (int i = 0; i != high; ++i)
    for (int k = 0; k != width; ++k)
      i_buffer[i][k] = init_p;
}
cglc::screen::screen() {
  struct winsize size;
  ioctl(STDIN_FILENO, TIOCGWINSZ, &size);
  wid = size.ws_col;
  hig = size.ws_row - 7;
  renderer.init(wid, hig);
}
cglc::screen::screen(int m_wid, int m_hig) {
  wid = m_wid;
  hig = m_hig;
  renderer.init(m_wid, m_hig);
}
bool cglc::screen::operator<<(baseStaticView & tmp) {
  if (!tmp.renderer.use || tmp.x >= wid || tmp.y >= hig || tmp.x < 0
      || tmp.y < 0)
    return false;
  buffer temp = tmp.draw();
  int i, k, m, n;
  i = k = 0;
  m = tmp.y;
  n = tmp.x;
  while (m < hig && i < temp.size()) {
    while (n < wid && k < temp[i].size()) {
      renderer[m][n] = temp[i][k];
      ++n;
      ++k;
    }
    ++m;
    ++i;
  }
  return true;
}
void cglc::screen::updscr(bool irfsh = true) {
  gotoxy(0, 0);
  for (int i = 0; i != renderer.i_buffer.size(); ++i) {
    for (int k = 0; k != renderer.i_buffer[i].size(); ++k) {
      if (renderer.i_buffer[i][k].img == '\n')
        continue;
      std::cout << "\e[" << renderer.i_buffer[i][k].text.color() << ";1m\e[" <<
        renderer.i_buffer[i][k].back.
        color() << ";1m" << renderer.i_buffer[i][k].img;
    }
    std::cout << std::endl;
  }
  if (irfsh)
    usleep(irefresh);
}
int irefresh_test() {
  clock_t start, finish;
  start = clock();
  int i = 0;
  finish = clock();
  while (((finish - start) / CLOCKS_PER_SEC) < 1) {
    finish = clock();
    ++i;
  }
  i = i / 1000;
  i = 12000 - i;
  return i;
}
void *loadthread(void *ptr) {
  std::cout << "\33[?25lLoading CGLC..." << std::endl;
  return 0;
}
int cglc_main();
int main() {
  pthread_t id;
  int ret = pthread_create(&id, NULL, loadthread, NULL);
  if (ret) {
    std::cout << "Load CGLC Error." << std::endl;
    return 0;
  }
  pthread_join(id, NULL);
  irefresh = irefresh_test();
  return cglc_main();
}