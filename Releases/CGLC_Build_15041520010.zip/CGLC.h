#ifndef GUARD_CGLC_H
#define GUARD_CGLC_H
// Covariate Graphics Library for Console
// T&C Studio出品
// 李登淳编写
// Copyright 2015 (C) T&C Studio
// Version 2.0.0 Formal
// Build 15-04-15-200-10
// Notice:Don't use UTF Chars!Only support English.
#include<iostream>
#include<string>
#include<vector>
#include<time.h>
#include<termios.h>
#include<pthread.h>
#include<sys/types.h>
#include<sys/ioctl.h>
#include<unistd.h>
void gotoxy(int x, int y) {
  std::cout << "\x1B[" << x << ";" << y << "f";
}
namespace cglc {
  class c_color {
    std::string m_color;
  public:
    c_color() {
      m_color = "37";
    } void operator=(std::string tmp_color) {
      m_color = tmp_color;
    } std::string & color() {
      return m_color;
    }
  };
  class point {
  public:
    char img;
    c_color text, back;
      point() {
      img = '@';
      text = "37";
      back = "40";
  }};
  class buffer {
    friend class screen;
    bool use;
    point init_p;
    int width, high;
      std::vector < std::vector < point >> i_buffer;
  public:
      c_color back;
      buffer() {
      back = "40";
      use = false;
    } void init(int, int);
    void clean();
    std::vector < point > &operator[](size_t i) {
      return i_buffer[i];
    }
    size_t size() {
      return i_buffer.size();
    }
  };
  class baseStaticView {
    friend class screen;
  protected:
    int m_wid, m_hig;
    buffer renderer;
  public:
    int x, y;
      baseStaticView() {
      x = y = 0;
      m_wid = m_hig = 1;
      renderer.init(m_wid, m_hig);
    } baseStaticView(int t_wid, int t_hig) {
      x = y = 0;
      m_wid = t_wid;
      m_hig = t_hig;
      renderer.init(m_wid, m_hig);
    }
    virtual buffer draw() {
      return renderer;
    }
  };
  class screen {
    friend bool operator<<(baseStaticView &, baseStaticView &);
    int wid, hig;
  public:
      buffer renderer;
      screen();
      screen(int, int);
    bool operator<<(baseStaticView &);
    void updscr(bool);
    int width() {
      return wid;
    }
    int high() {
      return hig;
    }
    void clean(bool cls_all = false) {
      if (cls_all)
        updscr(false);
      renderer.clean();
    }
  };
}
#endif