#include"CGLC.cpp"
#include"CGLC_Views.cpp"
#include<sstream>
std::string int2str(int n) {
  std::stringstream ss;
  std::string str;
  ss << n;
  ss >> str;
  return str;
}
int cglc_main() {
  cglc::screen scr;
  pencil pen;
  scr.renderer.back = "44";
  static_text txt0("Ball");
  static_text txt1("Ball");
  pen.nib.img = ' ';
  pen.nib.back = "47";
  bool xj = true;
  bool yj = true;
  ++txt1.y;
  while (true) {
    scr.clean();
    scr << pen;
    txt0 = "X=" + int2str(pen.x);
    scr << txt0;
    txt1 = "Y=" + int2str(pen.y);
    scr << txt1;
    if (pen.x == 0)
      xj = true;
    if (pen.y == 0)
      yj = true;
    if (pen.x == scr.width() - 1)
      xj = false;
    if (pen.y == scr.high() - 1)
      yj = false;
    if (xj)
      ++pen.x;
    else
      --pen.x;
    if (yj)
      ++pen.y;
    else
      --pen.y;
    scr.updscr();
  }
}