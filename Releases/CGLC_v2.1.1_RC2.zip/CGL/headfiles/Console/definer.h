#ifndef GUARD_CGL_Console_definer_h
#define GUARD_CGL_Console_definer_h
#include<iostream>
#include<thread>
#include<string>
#include<vector>
#include<time.h>
#include<termios.h>
#include<sys/ioctl.h>
#include<unistd.h>
// CGL for Console Class&Function definer
// Written by Mike Lee
namespace cglc {
  static bool copyright = true;
  static int automatic;
  static const int crazy_slow = 1000000;
  static const int slow = 18000;
  static const int normal = 14000;
  static const int fast = 10000;
  static const int max = 6000;
  static const int crazy_fast = 10;
  void move(int, int);
  class c_color;
  class c_point;
  class buffer;
  class baseStaticView;
  class screen;
  class c_text;
  typedef c_color color;
  typedef c_point point;
  typedef c_text text;
}
#endif