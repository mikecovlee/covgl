#ifndef GUARD_CGL5_H


#define GUARD_CGL5_H


// Covariant Graphics Library V
// Compile by Mike Covariant Lee
// 李登淳编写


#include "Source/CPGE/CPGE.cpp"
#include "Source/Controls/Controls.h"
#include "Source/Controls/Window.cpp"
#include "Source/Keyboard_Layout.h"


namespace cgl
{
	const char *cgl_version = "5.15.12.2";
	static baseView scr;
	static basic out;
}


#include "Source/ConsoleEdition.h"


namespace cgl
{
	static console cons;
	void boot();
	void exit();
	int launch(int (*)());
}


void cgl::boot()
{
	out.create();
	out.ClrScr();
	scr.adaptate();
}


void cgl::exit()
{
	out.destroy();
}


int cgl::launch(int (*func) ())
{
	boot();
	out.fresh();
	int ret = 0;
	try
	{
		ret = func();
	}
	catch(...)
	{
		out.destroy();
#ifdef CGL_TRACK
		cgl::track::caution_msg.log_to_file("CovGL_Cautions.log");
		cgl::track::error_msg.log_to_file("CovGL_Errors.log");
		cgl::track::stop("The specific reason is placed in the output file.");
#else
		cgl::track::stop("Please turn on Covariant GL Track Mod.");
#endif
	}
	exit();
	return ret;
}


#endif