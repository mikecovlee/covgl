#include "CGL/CGL5.h"


int start()
{
	cgl::cons.SetAttri(cgl::attribute::highlight);
	while (true)
	{
		int input = cgl::out.GetKbHitPer();
		if (input == -1)
			cgl::cons.print_to_scr();
		else
		{
			cgl::cons << (char)input;
		}
	}
}


int main()
{
	cgl::launch(start);
}