#include"CGLC_Views"
#include<sstream>
std::string int2str(int n) {
  std::stringstream ss;
  std::string str;
  ss << n;
  ss >> str;
  return str;
}
int cglc_main() {
  cglc::screen scr;
  window win(scr);
  pencil pen;
  win.renderer.back = "44";
  static_text txt0("Ball");
  static_text txt1("Ball");
  txt0.nib.back = txt1.nib.back = win.renderer.back;
  pen.nib = ' ';
  pen.nib.back = "47";
  bool xj = true;
  bool yj = true;
  ++txt1.y;
  while (true) {
    win.clean();
    scr.clean();
    win << pen;
    txt0 = "X=" + int2str(pen.x) + " Width=" + int2str(scr.width());
    win << txt0;
    txt1 = "Y=" + int2str(pen.y) + " High=" + int2str(scr.high());
    win << txt1;
    if (pen.x == 0)
      xj = true;
    if (pen.y == 0)
      yj = true;
    if (pen.x == win.width() - 1)
      xj = false;
    if (pen.y == win.high() - 1)
      yj = false;
    if (xj)
      ++pen.x;
    else
      --pen.x;
    if (yj)
      ++pen.y;
    else
      --pen.y;
    scr<<win;
    scr.updscr();
  }
}